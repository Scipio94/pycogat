from pycogat.cogat import cogat_split

cogat_split('/Users/scipio/Downloads/Grade 6 Student Profile Narrative .pdf',6)